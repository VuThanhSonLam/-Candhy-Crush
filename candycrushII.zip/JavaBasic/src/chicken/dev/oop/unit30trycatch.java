/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class unit30trycatch {

    public static void main(String[] args) {
        String test = "LeTrongBao";
        try {
            System.out.println("Before:");
            System.out.println(test.substring(9));
            System.out.println(test.substring(40));
            int a = 5;
            int b = 0;
            System.out.println(a/b);
            System.out.println("After:");
           
        }catch (StringIndexOutOfBoundsException e) {
            System.out.println("Error:" + e.toString());
        }
        catch(ArithmeticException e){
            System.out.println("Error:" + e.toString());
        }
        catch(Exception e){
            System.out.println("Error:" + e.toString()); // tat ca ngoai le.
            // write, log
            // show dialog
        }
        finally{
            System.out.println("Bao Dev Fuck The World"); //Always Done.
        }
    }

}
