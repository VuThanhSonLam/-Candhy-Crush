/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class unit26thuake {
    public static void main(String[] args) {
        ReferentBook book = new ReferentBook();
        book.move();
    }
}

interface Documents{
    void show();
}
// giua 2 interface
interface ReferentDoc extends Documents{
    
}
// giua class va interface
class Books implements Documents{
    @Override
    public void show(){
        
    }
    public void move(){
        
    }
}

class Book extends Books{
    
}

class Papers implements Documents{
    @Override
    public void show(){
        
    }
}

class ReferentBooks extends Papers implements Documents, ReferentDoc{

}