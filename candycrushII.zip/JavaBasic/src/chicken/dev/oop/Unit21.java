/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class Unit21 {
    
}
class student{
    private String name;
    private int score;
    public void study(){
        System.out.println("max score: ");
}
}
interface Person{
    public final static String MY_COUNTRY = "Viet Nam";  //khong doi.
    public void show(); //chua impliment.
}
abstract class Employee{
    private String name;
    public void Study(){
    }
    public abstract void move();
}
    