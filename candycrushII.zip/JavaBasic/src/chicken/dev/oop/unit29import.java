/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

import basic.chicken.dev.Arraydemo;
import basic.chicken.dev.whileloop;

/**
 *
 * @author USER
 */
public class unit29import {
    public static void main(String[] args) {
        unit28final test = new unit28final();
        Arraydemo demo = new Arraydemo();
        whileloop loop = new whileloop();

        
    }
}
