/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class unit28final {
    final float PI = 3.14f;
    int number;
    
    public static void main(String[] args) {
        unit28final test = new unit28final();
        test.number = 15;
        // final thi khong thay doi.
        // test.PI = 3.16f;
    }
    public void change(){
        number = 30;
        //PI = 3.12f;
    }
    void show(){
        
    }
}
final class Unit {      //khong the thua ke.
        final void show(){
            
        } // khong overridde khi co final
}
