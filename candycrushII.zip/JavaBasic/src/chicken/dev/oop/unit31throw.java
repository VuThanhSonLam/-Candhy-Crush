/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USER
 */
public class unit31throw {
    public static void main(String[] args) {
        building bd = new building();
        try {
            bd.go();
        } catch (InterruptedException ex) {
            Logger.getLogger(unit31throw.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Appear after 10s.");
        try {
            bd.show();
        } catch (MyException ex) {
            Logger.getLogger(unit31throw.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
class MyException extends Exception {
    
}
class building{
    public void show() throws MyException{
        int numberconnections = 0;
        while(numberconnections < 52) {
            numberconnections = numberconnections + 1;
        }
        if(numberconnections > 50) {
            throw new MyException();
        }
        System.out.println(numberconnections);
       
    }
    public void go() throws InterruptedException{
        Thread.sleep(1000);
    }
}

