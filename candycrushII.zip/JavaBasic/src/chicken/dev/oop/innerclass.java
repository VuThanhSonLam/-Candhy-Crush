/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class innerclass {

    public static void main(String[] args) {
        outer out = new outer();
        out.show();
        
        C c1 = new C();
        c1.show();
    }
}

class outer {

    public void show() {
        Inner in = new Inner();
        in.display();
    }

    class Inner {

        public void display() {
            System.out.println("Im an innner class");
        }
    }
}
class C{
        public void show(){
            outer.Inner in = new outer(). new Inner(); // muon su dung cua class tuong tu thi them outer.
            in.display();
        }
    }

