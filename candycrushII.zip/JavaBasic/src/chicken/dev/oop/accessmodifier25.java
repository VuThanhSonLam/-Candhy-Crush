/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class accessmodifier25 {
    public static void main(String[] args) {
        boss b1 = new boss();
        System.out.println(b1.age); // khong bao loi.
        System.out.println(b1.name); // khong bao loi.
        System.out.println(b1.address); // khong bao loi.
        //System.out.println(b1.numberofWives);   bao loi.
        
        //b1.showAge(); -> loi
        b1.showAddress();
}
}
class boss{
    public int age;   // Everywhere.
    protected String name;   // Same package, its subclass (outer, inner class).
    String address; //Same package.
    private int numberofWives;  //Only boss knows -> secret itself.
    
    private void showAge(){
        System.out.println(age);
    }
    public void showAddress(){
        System.out.println(address);
    }
}