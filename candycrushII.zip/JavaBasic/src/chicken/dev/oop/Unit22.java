/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class Unit22 {

    public static void main(String[] args) {
        A a1 = new A();
        a1.setName("BaoDev");
        System.out.println(a1.getName());

        A a2 = new A();
        a2.setName("Chicken");
        System.out.println(a2.getName());
        
        B b1 = new B();
        b1.setScore(8);
        System.out.println(b1.getScore());
    }
}

class A {   // Tao ra nhung phuong thuc giong nhau cho A nhung khac gia tri. ( a1, a2)

    private String name;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}

class B {
    private int score;
    
    public void setScore(int score){
        this.score = score;
    }

    public int getScore() {
        return score;
    }
    
}
