/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chicken.dev.oop;

/**
 *
 * @author USER
 */
public class interface24 {
    public static void main(String[] args) {
        manager man = new manager();
        man.show();
    }
}
interface human{
    public static final int AVG_AGE = 100;
    int AVG_WEIGHT = 60;
    
    public void show();
    void study();
}
class manager implements human{

    @Override
    public void show() {
        System.out.println("Average Age: " + AVG_AGE);
    }

    @Override
    public void study() {
    }

}