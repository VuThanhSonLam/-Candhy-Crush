/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basic.chicken.dev;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author USER
 */
public class timedemo {

    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        try {
            for (int i = 0; i < 1000; i++) {
                Thread.sleep(2);
            }
        } catch (Exception e) {

        }
        long end = System.currentTimeMillis();
        System.out.println(end - start);

        // get time nano: system.nanoTime()
        // Display the system time:
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String day = dateFormat.format(date);
        System.out.println(day);
    }
}
