/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basic.chicken.dev;

/**
 *
 * @author USER
 */
public class whileloop {

    public static void main(String[] args) {
        int i = 0;
        while (i < 10) {
            System.out.println("i:" + i);
            i++;
        }
        do {
            System.out.println("i:" + i);
            i++;
        } while (i < 10);
    }
}
