/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basic.chicken.dev;

/**
 *
 * @author USER
 */
public class Arraydemo {
    public static void main(String[] args) {
        int [] arrint1 = new int[10]; // 10 phan tu chua biet gia tri.
        int [] arrint2 = {2, 3, 4, 5}; // 4 phan tu cho truoc.
        int [][] arrint3 = new int[2][3];
        
        String [] arrstring = new String[5];
        Arraydemo [] arrdemo = new Arraydemo[10];
        for(int i = 0;i < arrint2.length; i++){
            System.out.println(arrint2[i]);
        }
        for(int i = 0; i < 2; i++){
            for(int j = 0; j<3; j++){
                System.out.print(arrint3[i][j] + " ");
            }
            System.out.println("");
        }
    }
}
