/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basic.chicken.dev;

/**
 *
 * @author USER
 */
public class function {

    public static void main(String[] args) {
        int day = 10;
        if (day > 5) {
            System.out.println("Larger than 5");
        } else {
            System.out.println("Smaller than 5");
        }
    }
}
