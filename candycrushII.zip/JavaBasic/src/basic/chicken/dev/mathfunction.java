/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basic.chicken.dev;

/**
 *
 * @author USER
 */
public class mathfunction {
    public static void main(String[] args) {
        int a = 5;
        int b = 16;
        a+=b;
        System.out.println(a);
        int num = Math.max(a, b);
        System.out.println(num);
        
    }
}
