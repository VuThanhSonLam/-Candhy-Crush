/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basic.chicken.dev;

/**
 *
 * @author USER
 */
public class Demokeywords {
    public static void main(String[] args) {
        char c = 65;
        System.out.println(c);
        short s= 255;
        System.out.println(s);
        int i = 123456;
        byte b = 127;
        b = (byte) i;
        System.out.println("i:  " + i + " b:" + b);     
    }
}
